﻿using System;
using System.Windows.Forms;

namespace a
{
    public partial class DisplayTextForm : Form
    {
        public DisplayTextForm(string text)
        {
            InitializeComponent();
            SetText(text);
        }

        public void SetText(string text)
        {
            textBox1.Text = text; // Assuming textBox1 is the name of your TextBox control
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(43, 63);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(714, 324);
            this.textBox1.TabIndex = 0;
            // 
            // DisplayTextForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox1);
            this.Name = "DisplayTextForm";
            this.Text = "DisplayTextForm";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.TextBox textBox1;
    }
}
