from flask import Flask, render_template, request, jsonify
import PyPDF2
import speech_recognition as sr
import os
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.probability import FreqDist
import heapq
from heapq import nlargest
from collections import defaultdict
from flask_cors import CORS
import nltk
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
from collections import Counter
from googletrans import Translator
import wikipedia
from fpdf import FPDF
from gtts import gTTS
import re
app = Flask(__name__)
CORS(app)

summarized = ""
keypoints = ""
TEXT = ""




def save_text_to_audio(text):
    # Extract the first word from the text
    first_word = text.split()[0]
    first_word =  remove_symbols(first_word)
    # Set the filename for the audio
    audio_filename = f"{first_word}.mp3"
    
    # Create gTTS object
    tts = gTTS(text=text, lang='en')
    
    # Save the audio file
    tts.save(audio_filename)





def remove_symbols(word):
    # Define regex pattern to match symbols
    pattern = r'[^\w\s]'
    
    # Remove symbols using regex
    cleaned_word = re.sub(pattern, '', word)
    
    return cleaned_word




def save_text_to_pdf(text):
    # Extract the first word from the text
    first_word = text.split()[0]
    first_word =  remove_symbols(first_word)
    
    # Set the filename for the PDF
    pdf_filename = f"{first_word}.pdf"
    
    # Create PDF object
    pdf = FPDF()
    pdf.add_page()
    
    # Set font for the text
    pdf.set_font("Arial", size = 12)
    
    # Add text to PDF
    pdf.multi_cell(0, 7, text)
    
    # Save the PDF
    pdf.output(pdf_filename)

# Example usage



def recommend_additional_resources(extracted_text):
    # Extract key points from the extracted text
    key_points = extract_keypoints(extracted_text)
    total = 0
    
    # Initialize a string to store the formatted content recommendations
    formatted_recommendations = ""
    
    # Search Wikipedia for articles related to the key points
    for key_point in key_points:
        try:
            # Search Wikipedia for articles related to the key point
            search_results = wikipedia.search(key_point, results=1)
            for i, result in enumerate(search_results):

                if total == 3:
                    return formatted_recommendations

                # Get the title and link of each search result
                page = wikipedia.page(result)
                formatted_recommendations += f"Title: {page.title}\nLink: {page.url}\n\n"
                total += 1
        except wikipedia.exceptions.DisambiguationError as e:
            # Skip disambiguation pages
            continue
        except wikipedia.exceptions.PageError as e:
            # Skip pages that do not exist
            continue
    
    # Return the formatted content recommendations
    return formatted_recommendations




def extract_keypoints(text):
    # Tokenize the text into sentences
    sentences = sent_tokenize(text)
    
    # Calculate the total number of sentences
    total_sentences = len(sentences)
    
    # Calculate the value of num_sentences (half of total_sentences)
    num_sentences = total_sentences // 2
    
    # Initialize a dictionary to store the count of unique words for each sentence
    unique_word_count = {}
    
    # Iterate over each sentence to calculate the count of unique words
    for sentence in sentences:
        words = [word.lower() for word in word_tokenize(sentence) if word.isalnum() and word.lower() not in stopwords.words('english')]
        unique_word_count[sentence] = len(set(words))
    
    # Sort the sentences based on the count of unique words in descending order
    sorted_sentences = sorted(unique_word_count.keys(), key=lambda x: unique_word_count[x], reverse=True)
    
    # Select the top num_sentences sentences as keypoints
    key_sentences = sorted_sentences[:num_sentences]
    
    # Add "Key Points" in bold text at the beginning
    keypoints_output = "*KEY POINTS :*\n\n"
    
    # Add key points from the text
    for sentence in key_sentences:
        keypoints_output += "- " + sentence + "\n"
    
    return keypoints_output


def save_audio(text):
    # Extract the first word from the text
    first_word = text.split()[0]
    first_word =  remove_symbols(first_word)
    # Set the filename for the audio
    audio_filename = f"{first_word}.mp3"
    
    # Create gTTS object
    tts = gTTS(text=text, lang='en')
    
    # Save the audio file
    tts.save(audio_filename)



def summarize_text(text):
    # Tokenize the text into sentences and words
    sentences = sent_tokenize(text)

    num_sentences = int(len(sentences)/2)
    words = word_tokenize(text.lower())
    
    # Remove stopwords
    stop_words = set(stopwords.words('english'))
    words = [word for word in words if word.isalnum() and word not in stop_words]
    
    # Calculate word frequencies
    word_freq = {}
    for word in words:
        if word in word_freq:
            word_freq[word] += 1
        else:
            word_freq[word] = 1
    
    # Calculate sentence scores based on word frequencies
    sentence_scores = {}
    for sentence in sentences:
        for word in word_tokenize(sentence.lower()):
            if word in word_freq:
                if sentence in sentence_scores:
                    sentence_scores[sentence] += word_freq[word]
                else:
                    sentence_scores[sentence] = word_freq[word]
    
    # Get the most important sentences based on scores
    summary_sentences = nlargest(num_sentences, sentence_scores, key=sentence_scores.get)
    
    # Combine the sentences to form the summary
    summary = ' '.join(summary_sentences)
    summary = "SUMMARY : \n\n" + summary

    return summary


def translate_to_urdu(text):

    translator = Translator()
    urdu_translation = translator.translate(text, src='en', dest='ur')
    urdu_text = urdu_translation.text
    urdu_text = 'URDU TRANSLATION : \n\n' + urdu_text
    return urdu_text



def extract_text_from_pdf(pdf_file_path):
    if os.path.exists(pdf_file_path):
        text = ""
        with open(pdf_file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            for page_num in range(len(pdf_reader.pages)):
                page = pdf_reader.pages[page_num]
                text += page.extract_text()
        return text
    else:
        return ""

def extract_text_from_audio(audio_file_path):
    if os.path.exists(audio_file_path):
        recognizer = sr.Recognizer()
        with sr.AudioFile(audio_file_path) as source:
            audio_data = recognizer.record(source)
            text = recognizer.recognize_google(audio_data)
        return text
    else:
        return ""

@app.route('/process', methods=['POST'])
def process():
    global TEXT

    pdf_text = request.form['pdf_text']
    action = request.form['action']

    if action == 'summarize':
        summarized_text = summarize_text(pdf_text)
        TEXT = summarized_text
        operation = "summarized"
        
    elif action == 'highlight':
        key_points = extract_keypoints(pdf_text)
        TEXT = key_points
        operation = "keypoints"

    elif action == 'translate':
        TEXT = translate_to_urdu(pdf_text)
        operation = "translate"

    elif action == 'resources':
        TEXT = recommend_additional_resources(pdf_text)
        operation = "links of resources"


    elif action == 'download_t':
        operation = "download text"
        save_text_to_pdf(TEXT)

    elif action == 'download_a':
        operation = "download audio"
        save_audio(TEXT)
    else:
        TEXT = pdf_text
        operation = ""

    return jsonify({'text': TEXT, 'operation': operation})

@app.route('/')
def index():
    global TEXT

    # Paths to PDF and audio files
    # Get the current directory
    current_directory = os.getcwd()

    # Specify the relative path to the WAV and MP3 files
    relative_path_wav = os.path.join("..", "..", "saved", "a.wav")
    relative_path_mp3 = os.path.join("..", "..", "saved", "a.mp3")
    relative_path = os.path.join("..", "..", "saved", "a.pdf")

    # Construct the full paths
    file_path_wav = os.path.join(current_directory, relative_path_wav)
    file_path_mp3 = os.path.join(current_directory, relative_path_mp3)
    pdf_path = os.path.join(current_directory, relative_path)

    # Extract text from PDF and audio if files exist
    pdf_text = extract_text_from_pdf(pdf_path)

    if os.path.exists(file_path_wav):
        audio_text = extract_text_from_audio(file_path_wav)
    elif os.path.exists(file_path_mp3):
        audio_text = extract_text_from_audio(file_path_mp3)
    else:
        audio_text = ""

    pdf_text = pdf_text + audio_text


    operation = ""


    TEXT = pdf_text + audio_text

    return render_template('index.html', pdf_text=TEXT, audio_text=operation )


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)









