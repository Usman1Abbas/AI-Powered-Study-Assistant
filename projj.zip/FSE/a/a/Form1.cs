﻿using System;
using System.IO;
using System.Windows.Forms;

namespace a
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void uploadButton_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "PDF Files|*.pdf";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // Get the directory of the current executable
                    string currentDirectory = AppDomain.CurrentDomain.BaseDirectory;

                    // Specify the relative destination folder path for PDF files
                    string relativeDestinationFolder = @"..\..\saved"; // Relative path to the 'saved' folder
                    string destinationFolder = Path.Combine(currentDirectory, relativeDestinationFolder);

                    // Specify the file name to "a.pdf"
                    string fileName = "a.pdf";

                    // Combine the destination folder with the file name to get the full destination path
                    string destinationPath = Path.Combine(destinationFolder, fileName);

                    // Create directory if it doesn't exist
                    Directory.CreateDirectory(destinationFolder);

                    // Copy the PDF file to the destination folder
                    File.Copy(openFileDialog1.FileName, destinationPath, true);

                    // Start Flask server as a separate process
                    StartFlaskServer();

                    // Navigate to the specified URL
                    string url = "https://www.google.com/";
                    webBrowser1.Navigate(url); // Navigate to the URL using WebBrowser control
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void StartFlaskServer()
        {
            // Define the path to your Flask application script
            string flaskAppPath = @"..\..\app.py"; // Update with the actual path to your Flask application script

            // Start the Flask server using cmd
            System.Diagnostics.Process.Start("cmd.exe", $"/C python \"{flaskAppPath}\"");
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Audio Files|*.mp3;*.wav;*.ogg";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // Get the directory of the current executable
                    string currentDirectory = AppDomain.CurrentDomain.BaseDirectory;

                    // Specify the relative destination folder path for audio files
                    string relativeDestinationFolder = @"..\..\saved"; // Relative path to the 'saved' folder
                    string destinationFolder = Path.Combine(currentDirectory, relativeDestinationFolder);

                    // Specify the file name to "a.wav"
                    string fileName = "a.wav";

                    // Combine the destination folder with the file name to get the full destination path
                    string destinationPath = Path.Combine(destinationFolder, fileName);

                    // Create directory if it doesn't exist
                    Directory.CreateDirectory(destinationFolder);

                    // Copy the audio file to the destination folder
                    File.Copy(openFileDialog1.FileName, destinationPath, true);

                    // Start Flask server as a separate process
                    StartFlaskServer();

                    // Navigate to the specified URL
                    string url = "https://www.google.com/";
                    webBrowser1.Navigate(url); // Navigate to the URL using WebBrowser control
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            // Close the current form
            this.Close();

            // Forcefully exit the application
            Environment.Exit(0);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Specify the path to the folder where records are saved
            string folderPath = @"..\..\saved"; // Replace with your folder path

            try
            {
                // Check if the folder exists
                if (Directory.Exists(folderPath))
                {
                    // Delete all files in the folder
                    foreach (string filePath in Directory.GetFiles(folderPath))
                    {
                        File.Delete(filePath);
                    }
                    
                }

                // Optionally, you can also clear any data or reset controls on your form here

                // Show a message to indicate successful clearing
                MessageBox.Show("Data cleared successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                // Handle any exceptions
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
